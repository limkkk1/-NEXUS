import os
import re
import shutil
import argparse
import subprocess
import logging
import unicodedata

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def find_path(target, start_dir):
    try:
        cmd = ["find", start_dir, "-name", target, "-type", "f"]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        paths = result.stdout.strip().split('\n')
        return paths[0] if paths and paths[0] else None
    except Exception as e:
        logging.error(f"查找文件 {target} 出错: {e}")
        return None

def find_dir(target, start_dir):
    try:
        cmd = ["find", start_dir, "-name", target, "-type", "d"]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        paths = result.stdout.strip().split('\n')
        return paths[0] if paths and paths[0] else None
    except Exception as e:
        logging.error(f"查找目录 {target} 出错: {e}")
        return None

def find_screen_executable(screen_dir):
    screen_path = os.path.join(screen_dir, "screen")
    if os.path.isfile(screen_path) and os.access(screen_path, os.X_OK):
        return screen_path
    logging.warning(f"在 {screen_dir} 未找到可执行的 screen 文件")
    return None

def prompt_for_path(target, target_type):
    while True:
        path = input(f"未找到 {target_type} '{target}'，请手动输入完整路径（回车跳过使用默认值）：")
        if not path:
            return None
        path = os.path.abspath(path)
        if target_type == "file" and os.path.isfile(path) and os.access(path, os.R_OK):
            return path
        elif target_type == "directory" and os.path.isdir(path) and os.access(path, os.R_OK):
            return path
        print(f"路径无效或不可访问，请确保 '{path}' 是有效的 {target_type}。")

def clean_node_ids_file(file_path):
    if not os.path.isfile(file_path):
        logging.error(f"节点 ID 文件 {file_path} 不存在")
        return False

    try:
        with open(file_path, 'r', encoding='utf-8-sig') as f:
            lines = f.readlines()
    except Exception as e:
        logging.error(f"读取文件 {file_path} 失败: {e}")
        return False

    cleaned_ids = []
    seen_ids = set()
    empty_lines = 0
    duplicate_lines = 0
    invalid_lines = 0

    for line in lines:
        cleaned_line = ''.join(c for c in line if unicodedata.category(c)[0] != 'C').strip()
        if not cleaned_line:
            empty_lines += 1
            continue
        if cleaned_line.isdigit():
            if cleaned_line not in seen_ids:
                cleaned_ids.append(cleaned_line)
                seen_ids.add(cleaned_line)
            else:
                duplicate_lines += 1
        else:
            invalid_lines += 1

    logging.info(f"清理 {file_path}: 移除 {empty_lines} 个空行，{duplicate_lines} 个重复 ID，{invalid_lines} 个无效行")
    if not cleaned_ids:
        logging.error(f"文件 {file_path} 清理后无有效节点 ID")
        return False

    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(cleaned_ids) + '\n')
        logging.info(f"已清理并保存节点 ID 文件: {file_path}")
        return True
    except Exception as e:
        logging.error(f"保存清理后的文件 {file_path} 失败: {e}")
        return False

def get_paths(base_dir):
    # 默认路径
    default_nexus_bin = "/home/user/.nexus/bin/nexus-network"
    
    # 尝试使用默认路径，如果文件不存在，再通过 find 查找
    nexus_bin = default_nexus_bin if os.path.isfile(default_nexus_bin) else find_path("nexus-network", base_dir)
    
    paths = {
        "nexus_bin": nexus_bin,  # 使用默认路径或者通过 find 查找得到的路径
        "all_ids_file": find_path("id.txt", base_dir),
        "last_index_file": find_path("last_batch_index.txt", base_dir),
        "groups_dir": find_dir("groups", base_dir),
        "log_dir": find_dir("logs", base_dir),
        "screen_dir": find_dir("screen-4.9.1", base_dir)
    }

    defaults = {
        "nexus_bin": f"{base_dir}/build-nexus083/clients/cli/target/release/nexus-network",
        "all_ids_file": f"{base_dir}/nexus-batch/id.txt",
        "last_index_file": f"{base_dir}/nexus-batch/last_batch_index.txt",
        "groups_dir": f"{base_dir}/nexus-batch/groups",
        "log_dir": f"{base_dir}/nexus-batch/logs",
        "screen_dir": f"{base_dir}/screen-4.9.1"
    }

    not_found = []
    for key, path in paths.items():
        if not path:
            not_found.append(key)
            logging.info(f"未找到 {key.replace('_', ' ')}")
            if key in ["nexus_bin", "all_ids_file", "last_index_file"]:
                paths[key] = prompt_for_path(defaults[key].split('/')[-1], "file") or defaults[key]
            else:
                paths[key] = prompt_for_path(defaults[key].split('/')[-1], "directory") or defaults[key]

    # 清理 id.txt
    if paths["all_ids_file"] and os.path.isfile(paths["all_ids_file"]):
        if not clean_node_ids_file(paths["all_ids_file"]):
            logging.warning(f"清理 {paths['all_ids_file']} 失败，可能影响脚本运行")

    # 检查是否在 WSL 环境中
    is_wsl = os.path.exists("/proc/sys/fs/binfmt_misc/WSLInterop") or "WSL" in os.environ.get("WSL_DISTRO_NAME", "")
    screen_bin = None
    if is_wsl:
        system_screen = shutil.which("screen")
        if system_screen and os.access(system_screen, os.X_OK):
            logging.info(f"检测到 WSL 中已安装 screen：{system_screen}")
            screen_bin = system_screen
        else:
            logging.info("WSL 中未找到系统 screen，尝试使用 script 提供的 screen-4.9.1")
    else:
        logging.info("非 WSL 环境，尝试使用 script 提供的 screen-4.9.1")

    if not screen_bin and paths["screen_dir"]:
        screen_bin = find_screen_executable(paths["screen_dir"])
        if not screen_bin:
            logging.warning("未找到本地 screen-4.9.1 可执行文件")
            screen_bin = prompt_for_path("screen", "file") or os.path.join(paths["screen_dir"], "screen")
    
    if screen_bin:
        logging.info(f"将使用 screen 可执行文件：{screen_bin}")
    else:
        logging.info("未找到任何 screen 可执行文件，将使用系统默认 screen")
    paths["screen_bin"] = screen_bin if screen_bin else ""

    if not_found:
        print("\n以下路径未自动找到，已使用用户输入或默认值：")
        for key in not_found:
            print(f"{key.replace('_', ' ')}: {paths[key]}")

    return paths

def update_script(script_path, paths):
    if not os.path.isfile(script_path):
        logging.error(f"脚本 {script_path} 不存在")
        raise FileNotFoundError(f"脚本 {script_path} 不存在")

    with open(script_path, 'r') as f:
        content = f.read()

    replacements = {
        r'^NEXUS_BIN\s*=\s*"[^"]*"\s*$': f'NEXUS_BIN="{paths["nexus_bin"]}"',
        r'^ALL_IDS_FILE\s*=\s*"[^"]*"\s*$': f'ALL_IDS_FILE="{paths["all_ids_file"]}"',
        r'^LAST_INDEX_FILE\s*=\s*"[^"]*"\s*$': f'LAST_INDEX_FILE="{paths["last_index_file"]}"',
        r'^GROUPS_DIR\s*=\s*"[^"]*"\s*$': f'GROUPS_DIR="{paths["groups_dir"]}"',
        r'^LOG_DIR\s*=\s*"[^"]*"\s*$': f'LOG_DIR="{paths["log_dir"]}"',
        r'\bscreen\b': '${SCREEN_BIN:-screen}'
    }

    for pattern, replacement in replacements.items():
        content = re.sub(pattern, replacement, content, flags=re.MULTILINE)

    if paths["screen_bin"]:
        screen_bin_line = f'SCREEN_BIN="{paths["screen_bin"]}"\n'
    else:
        screen_bin_line = f'SSCREEN_BIN=""\n'
    content = screen_bin_line + content

    new_script_path = script_path.replace('.sh', '_adapted.sh')
    with open(new_script_path, 'w') as f:
        f.write(content)

    os.chmod(new_script_path, 0o755)
    logging.info(f"生成适配脚本：{new_script_path}")
    print(f"\n已生成适配脚本：{new_script_path}")
    print("请确认路径：")
    for k, v in paths.items():
        print(f"{k}: {v}")

def main():
    parser = argparse.ArgumentParser(description='适配 Nexus 脚本路径')
    parser.add_argument('--script', required=True, help='Nexus 脚本路径')
    parser.add_argument('--base-dir', default=os.path.expanduser('~'), help='搜索基础目录')
    args = parser.parse_args()

    paths = get_paths(args.base_dir)
    update_script(args.script, paths)

if __name__ == '__main__':
    main()
