#!/bin/bash

# Nexus 多ID运行管理工具（v4.2.1）
# 功能：管理 Nexus 网络节点的批量启动、轮换、状态检查和分组操作
# 修复：统一返回菜单逻辑，修复 submenu_option 未定义，优化提示和无效输入处理

# 预设路径
export PATH="$HOME/local/bin:$PATH"

NEXUS_BIN="/home/ub38668124983e638a45b37027db478f/build-nexus083/clients/cli/target/release/nexus-network"
ALL_IDS_FILE="/home/ub38668124983e638a45b37027db478f/nexus-batch/all_node_ids.txt"
GROUPS_DIR="/home/ub38668124983e638a45b37027db478f/nexus-batch/groups"
LOG_DIR="/home/ub38668124983e638a45b37027db478f/nexus-batch/logs"
BATCH_LOG="$LOG_DIR/batch_history.log"
ROTATION_LOG="$LOG_DIR/rotation_schedule.log"
LAST_INDEX_FILE="/home/ub38668124983e638a45b37027db478f/nexus-batch/last_batch_index.txt"
BATCH_SIZE=30

# 初始化目录
mkdir -p "$LOG_DIR" "$GROUPS_DIR"

# 检查必要文件
if [ ! -f "$ALL_IDS_FILE" ]; then
    echo "错误：$ALL_IDS_FILE 不存在，请确保文件已创建并包含节点 ID 列表。"
    exit 1
fi
if [ ! -f "$NEXUS_BIN" ]; then
    echo "错误：$NEXUS_BIN 不存在或不可执行，请检查路径。"
    exit 1
fi

# 计算总批次
get_total_batches() {
    mapfile -t IDS < "$ALL_IDS_FILE"
    total=${#IDS[@]}
    echo $(( (total + BATCH_SIZE - 1) / BATCH_SIZE ))
}

# 启动指定批次
start_batch() {
    batch_num=$1
    mapfile -t IDS < "$ALL_IDS_FILE"
    start_idx=$(( (batch_num - 1) * BATCH_SIZE ))
    BATCH_IDS=("${IDS[@]:$start_idx:$BATCH_SIZE}")

    echo "正在启动第 $batch_num 批..."
    for id in "${BATCH_IDS[@]}"; do
        if screen -ls | grep -q "nexu_${id}"; then
            echo "ID $id 已在运行，跳过。"
        else
            # 启动节点，异步执行
            screen -S "nexu_${id}" -dm bash -c "$NEXUS_BIN start --node-id $id"
            # 确认是否成功启动
            if screen -ls | grep -q "nexu_${id}"; then
                echo "已启动ID：$id"

                # 友好倒计时等待3秒
                WAIT=3
                echo -n "等待 $WAIT 秒"
                for ((i=WAIT; i>0; i--)); do
                    echo -ne "\r等待 $i 秒  "
                    sleep 1
                done
                echo -e "\r等待完成，开始启动下一个ID。   "
            else
                echo "启动ID $id 失败。"
            fi
        fi
    done

    echo "运行编号: $(date +%s)" >> "$BATCH_LOG"
    echo "批次: 第 $batch_num 批" >> "$BATCH_LOG"
    echo "时间: $(date +'%F %T')" >> "$BATCH_LOG"
    echo "ID列表: ${BATCH_IDS[*]}" >> "$BATCH_LOG"
    echo "-----" >> "$BATCH_LOG"
    echo "$batch_num" > "$LAST_INDEX_FILE"
    
    # 提示批次完成并返回当前子菜单
    read -p "批次启动完成。按回车返回当前子菜单..."
    clear  # 清理屏幕

    batch_menu  # 调用子菜单函数返回
}

start_id_by_batch() {
    clear
    total_batches=$(get_total_batches)
    mapfile -t IDS < "$ALL_IDS_FILE"
    FIRST_BATCH_IDS=("${IDS[@]:0:$BATCH_SIZE}")

    # 获取已运行的批次
    RUN_BATCHES=()

    for batch_num in $(seq 1 $total_batches); do
        start_idx=$(( (batch_num - 1) * BATCH_SIZE ))
        BATCH_IDS=("${IDS[@]:$start_idx:$BATCH_SIZE}")
        
        running_count=0
        for id in "${BATCH_IDS[@]}"; do
            if screen -ls | grep -q "nexu_${id}"; then
                running_count=$((running_count + 1))
            fi
        done

        # 如果当前批次有运行的节点，则将批次编号加入已运行批次
        if (( running_count > 0 )); then
            RUN_BATCHES+=($batch_num)
        fi
    done

    echo "----------- 一键后台启动ID -----------"

    # 检查第一批的运行状态，并显示已运行的数量
    first_batch_running_count=0
    for id in "${FIRST_BATCH_IDS[@]}"; do
        if screen -ls | grep -q "nexu_${id}"; then
            first_batch_running_count=$((first_batch_running_count + 1))
        fi
    done

    if [[ " ${RUN_BATCHES[@]} " =~ " 1 " ]]; then
        echo " 1) 运行第一批（前${BATCH_SIZE}个） | 已运行 (${first_batch_running_count})"
    else
        echo " 1) 运行第一批（前${BATCH_SIZE}个） | ❌ 未运行"
    fi

    # 显示已运行批次和剩余可运行批次在同一行
    echo -n "当前已运行批次："
    if [ ${#RUN_BATCHES[@]} -gt 0 ]; then
        for batch in "${RUN_BATCHES[@]}"; do
            echo -n "第 $batch 批 "
        done
    else
        echo -n "无 "
    fi

    # 动态计算剩余可运行批次
    ALL_BATCHES=($(seq 1 $total_batches))
    LEFT=()
    for b in "${ALL_BATCHES[@]}"; do
        if [[ ! " ${RUN_BATCHES[*]} " =~ " $b " ]]; then
            LEFT+=("$b")
        fi
    done

    echo -n "| 剩余可运行批次："
    if [ ${#LEFT[@]} -gt 0 ]; then
        for batch in "${LEFT[@]}"; do
            echo -n "第 $batch 批 "
        done
    else
        echo -n "无"
    fi
    echo ""

    echo " 2) 选择具体批次（共 $total_batches 批）"
    echo " 0) 返回主菜单"
    echo "------------------------------------------"
    read -p "请选择批次操作 (0-2): " choice

    case $choice in
        1) start_batch 1 ;;
        2)
            while true; do
                clear
                echo -n "当前已运行批次："
                if [ ${#RUN_BATCHES[@]} -gt 0 ]; then
                    for batch in "${RUN_BATCHES[@]}"; do
                        echo -n "第 $batch 批 "
                    done
                else
                    echo -n "无 "
                fi

                ALL_BATCHES=($(seq 1 $total_batches))
                LEFT=()
                for b in "${ALL_BATCHES[@]}"; do
                    if [[ ! " ${RUN_BATCHES[*]} " =~ " $b " ]]; then
                        LEFT+=("$b")
                    fi
                done

                echo -n "| 剩余可运行批次："
                if [ ${#LEFT[@]} -gt 0 ]; then
                    for batch in "${LEFT[@]}"; do
                        echo -n "第 $batch 批 "
                    done
                else
                    echo -n "无"
                fi
                echo ""

                echo ""
                echo "可执行操作："
                echo "(1) 输入数字 N 启动第 N 批（例如 2）"
                echo "(2) 输入 C 加批次号关闭第 N 批（例如 C1）"
                echo "(3) 输入 0 返回主菜单"
                echo ""

                read -p "请输入操作指令（如 2 或 C1 或 0）: " batch_num

                # 关闭批次
                if [[ "$batch_num" =~ ^[cC]([0-9]+)$ ]]; then
                    close_num="${BASH_REMATCH[1]}"
                    if (( close_num < 1 || close_num > total_batches )); then
                        echo "无效批次号。"
                        read -p "按回车继续批次选择菜单..."
                        continue
                    fi

                    # 获取该批次的 ID 列表
                    ids_line=$(awk -v b="批次: 第 $close_num 批" '
                        BEGIN { RS="-----"; FS="\n" }
                        {
                            for (i=1; i<=NF; i++) {
                                if ($i == b) found=1;
                                if (found && $i ~ /^ID列表:/) {
                                    gsub("ID列表: ", "", $i);
                                    print $i;
                                    found=0;
                                    break;
                                }
                            }
                        }' "$BATCH_LOG")

                    if [ -z "$ids_line" ]; then
                        echo "批次 $close_num 无法找到 ID 记录，可能未运行或未记录。"
                        read -p "按回车继续批次选择菜单..."
                        continue
                    fi

                    echo "正在关闭第 $close_num 批的ID..."
                    closed_ids=()

                    for id in $ids_line; do
                        if screen -ls | grep -q "nexu_${id}"; then
                            screen -S "nexu_${id}" -X quit
                            closed_ids+=("$id")  # 将已关闭的 ID 添加到数组中
                            echo "已关闭 ID $id"
                        else
                            if [[ ! " ${closed_ids[*]} " =~ " $id " ]]; then
                                echo "ID $id 未运行"
                            fi
                        fi
                    done
                    echo "第 $close_num 批已处理完毕。"
                    read -p "按回车继续批次选择菜单..."
                    continue
                fi

                if [[ "$batch_num" == "0" ]]; then
                    echo "已取消，返回主菜单。"
                    return
                elif [[ "$batch_num" =~ ^[0-9]+$ ]] && (( batch_num >= 1 && batch_num <= total_batches )); then
                    start_batch "$batch_num"
                    return
                else
                    echo "输入无效，请重新选择"
                    read
                    clear
                    return
                fi
            done
            ;;
        0) return ;;
        *) 
            echo "输入无效，请重新选择"
            read
            clear
            return
            ;;
    esac
}

schedule_next_batch() {
    total_batches=$(get_total_batches)
    delay=120  # 默认延迟时间为120分钟

    # 记录每个批次的启动时间
    declare -A batch_start_times

    # 记录已手动启动的批次
    declare -A manual_started_batches

    # 文件保存当前运行的批次状态
    CURRENT_BATCH_FILE="$LOG_DIR/current_batch.txt"
    START_TIME_FILE="$LOG_DIR/start_time.txt"

    # 如果文件不存在，初始化为0（第一个批次）
    if [ ! -f "$CURRENT_BATCH_FILE" ]; then
        echo 0 > "$CURRENT_BATCH_FILE"
    fi

    # 读取当前批次信息
    current_batch=$(cat "$CURRENT_BATCH_FILE")
    next_batch=$((current_batch + 1))
    if ((next_batch > total_batches)); then
        next_batch=1  # 如果批次编号超过最大批次数量，重置为第 1 批
    fi

    # 判断是否已经有启动时间记录
    if [ ! -f "$START_TIME_FILE" ]; then
        echo "没有找到启动时间文件，首次启动时将记录当前时间。"
        current_time=$(date +%s)  # 获取当前时间戳（秒）
        echo "$current_time" > "$START_TIME_FILE"
    else
        current_time=$(cat "$START_TIME_FILE")  # 读取已记录的启动时间
    fi

    # 禁用启动轮换功能（如果已经启动）
    auto_rotate_started=0
    if [ "$current_batch" -ge "$next_batch" ]; then
        auto_rotate_started=1
    fi

    while true; do
        clear
        echo "========== 行轮换批次 =========="

        # 获取当前正在运行的批次
        running_batches=()
        for batch_num in $(seq 1 $total_batches); do
            start_idx=$(( (batch_num - 1) * BATCH_SIZE ))
            BATCH_IDS=("${IDS[@]:$start_idx:$BATCH_SIZE}")
            
            # 检查当前批次是否有节点在运行
            for id in "${BATCH_IDS[@]}"; do
                if screen -ls | grep -q "nexu_${id}"; then
                    running_batches+=("$batch_num")
                    break
                fi
            done
        done

        # 获取最新运行的批次，如果没有运行的批次，默认为 0
        if [ ${#running_batches[@]} -gt 0 ]; then
            latest_batch=${running_batches[-1]}  # 获取最后一个已运行的批次
        else
            latest_batch=0
        fi

        # 获取当前时间（用于计算已运行时间）
        current_time_now=$(date +%s)  # 获取当前时间戳
        elapsed_time=$((current_time_now - current_time))  # 计算从启动时间到现在的秒数
        elapsed_minutes=$((elapsed_time / 60))  # 转换为分钟

        echo "提示：当前已运行到第 $latest_batch 批，共 $total_batches 批，已经运行第 $latest_batch 批 $elapsed_minutes 分钟"

        # 计算预计剩余时间（减去已运行的时间）
        remaining_time=$((delay - elapsed_minutes))
        if [ $remaining_time -lt 0 ]; then
            remaining_time=0
        fi

        echo "预计下批次开始时间：剩余 $remaining_time 分钟后将开始"

        # 提供选择操作的菜单
        echo "----------------------------------"
        echo "剩余可运行批次："
        for ((i = latest_batch + 1; i <= total_batches; i++)); do
            echo "第 $i 批"
        done
        echo "----------------------------------"

        # 根据是否已经启动，禁用选项1
        if [ "$auto_rotate_started" -eq 1 ]; then
            echo "1、启动自动轮换"
        else
            echo "1、是否选择开启轮换ID运行？"
        fi

        echo "2、不选择"
        echo "3、退出菜单"
        echo "4、刷新菜单"
        echo "----------------------------------"

        # 用户选择是否开启自动轮换或刷新菜单
        read -p "请选择批次操作 (1-4): " choice
        case $choice in
            1)
                if [ "$auto_rotate_started" -eq 0 ]; then
                    # 启动下一个批次
                    echo "已开启自动轮换...预计下一个批次开始时间：剩余 $remaining_time 分钟后将开始"
                    echo "$(date +'%F %T') - 批次 $next_batch 启动。" >> "$LOG_DIR/batch_rotation.log"
                    screen -dmS auto_batch_$next_batch bash -c "sleep $((remaining_time * 60)); $0 --start-batch $next_batch"
                    echo "$(date +'%F %T') - 批次 $next_batch 启动时间：$(date +'%T')" >> "$LOG_DIR/batch_start_times.log"
                    
                    # 更新当前批次状态
                    echo $next_batch > "$CURRENT_BATCH_FILE"
                    
                    # 标记手动启动的批次
                    manual_started_batches[$next_batch]=1
                    # 禁用再次启动功能
                    auto_rotate_started=1
                else
                    echo "自动轮换已启动，等待下一个批次。"
                fi
                ;;
            2)
                echo "不选择启动轮换，跳过当前批次。"
                ;;
            3)
                echo "退出菜单..."
                return  # 退出菜单，继续执行轮换任务
                ;;
            4)
                echo "刷新菜单..."
                continue  # 刷新并继续执行菜单
                ;;
            *)
                echo "无效选择，请输入正确的选项。"
                ;;
        esac

        # 提供退出操作或返回菜单
        echo "----------------------------------"
        read -p "按回车返回菜单..."
        return  # 返回菜单
    done
}

# 检测并恢复失效批次
detect_and_recover_batches() {
    echo "  检测失效批次（检查条件后台是否运行）"
    declare -A latest_batches
    awk 'BEGIN{RS="-----"; FS="\n"} {
        for(i=1;i<=NF;i++){
            if($i ~ /^批次:/){gsub("批次: ","",$i); batch=$i}
            if($i ~ /^ID列表:/){gsub("ID列表: ","",$i); ids=$i}
        }
        if(batch && ids){ latest_batches[batch]=ids }
    }' "$BATCH_LOG"

    need_recover=()
    for batch in "${!latest_batches[@]}"; do
        ids=( ${latest_batches[$batch]} )
        running=0
        for id in "${ids[@]}"; do
            screen -ls | grep -q "nexu_${id}" && running=$((running+1))
        done
        if (( running < ${#ids[@]} / 2 )); then
            echo "⚠️ $batch 多数 ID 停止，建议重跑"
            need_recover+=("$batch")
        else
            echo "✅ $batch 多数 ID 正常运行"
        fi
    done

    if [ ${#need_recover[@]} -eq 0 ]; then
        echo "无失效ID。"
        read -p "按回车返回主菜单..."
        return
    fi

    echo "是否恢复以上失效批次？"
    echo " 1) 是，立即重跑"
    echo " 2) 否，返回主菜单"
    read -p "请选择 (1-2): " choice
    case $choice in
        1)
            for batch in "${need_recover[@]}"; do
                num=$(echo "$batch" | grep -o '[0-9]\\+')
                start_batch "$num"
            done
            ;;
        *) return ;;
    esac
}

# 查看节点状态
view_node_status() {
    echo "抓取每个 ID 的第5行状态："
    sessions=$(screen -ls | grep "nexu_" | awk '{print $1}' | tr -d '\0')
    if [ -z "$sessions" ]; then
        echo "无ID运行"
    else
        for s in $sessions; do
            screen -S "$s" -X hardcopy "/tmp/${s}.log"
            if [ -f "/tmp/${s}.log" ]; then
                fifth=$(sed -n '5p' "/tmp/${s}.log" | strings | tr -d '\0' | tr -d '\n')
                echo "$fifth"
            else
                echo "（无日志）"
            fi
            rm -f "/tmp/${s}.log"
        done
    fi
    read -p "按回车返回主菜单..."
    return
}

# 查看批次日志
view_batch_log() {
    clear
    echo "✅ 历史运行记录（每批仅显示最后一次）"
    awk 'BEGIN { RS="-----"; FS="\n" }
    {
        for (i=1; i<=NF; i++) {
            if ($i ~ /^批次:/) b=$i;
            else if ($i ~ /^时间:/) t=$i;
            else if ($i ~ /^ID列表:/) id=$i;
        }
        if (b && t && id) print b"\\n"t"\\n"id"\\n-----------------------------";
    }' "$BATCH_LOG" | tac | awk '!a[$0]++' | tac
    read -p "按回车返回主菜单..."
    return
}

# 关闭所有节点
stop_all_nodes() {
    echo "关闭所有 ID 的 screen 会话..."
    for s in $(screen -ls | grep "nexu_" | awk '{print $1}'); do
        screen -S "$s" -X quit
        echo "已关闭 $s"
    done
    read -p "操作完成。按回车返回主菜单..."
    return
}

# 其他功能菜单
other_functions_menu() {
    while true; do
        clear
        echo "========= 其他功能 ========="
        echo " 1) 查看已有分组"
        echo " 2) 创建新分组"
        echo " 3) 编辑分组（带提示）"
        echo " 4) 启动某个分组"
        echo " 5) 进入某个 ID 的运行界面"
        echo " 0) 返回主菜单"
        echo "============================"
        read -p "请选择操作 (0-5): " sub
        case $sub in
            1)
                echo "可用分组文件如下："
                ls "$GROUPS_DIR" | grep ".txt$" || echo "无分组文件"
                read -p "按回车继续其他功能菜单..."
                ;;
            2)
                read -p "请输入新分组名（不带.txt，输入 0 返回）: " newname
                [ "$newname" == "0" ] && continue
                filepath="$GROUPS_DIR/group_${newname}.txt"
                read -p "请输入多个 ID，用空格分隔: " idline
                echo "$idline" | tr ' ' '\\n' > "$filepath"
                echo "✅ 已创建 $filepath"
                read -p "是否立即编辑该分组？(y/n): " edit
                if [ "$edit" == "y" ]; then
                    echo "提示：nano 操作说明：Ctrl+O 保存，Ctrl+X 退出"
                    read -p "按回车进入编辑器..."
                    nano "$filepath"
                    echo "✅ 编辑完成。"
                fi
                read -p "按回车继续其他功能菜单..."
                ;;
            3)
                read -p "请输入要编辑的分组文件名（如 group_xxx.txt，或输入 0 返回）: " file
                [ "$file" == "0" ] && continue
                full="$GROUPS_DIR/$file"
                if [ -f "$full" ]; then
                    echo "提示：nano 操作说明：Ctrl+O 保存，Ctrl+X 退出"
                    read -p "按回车进入编辑器..."
                    nano "$full"
                    echo "✅ 编辑完成。"
                else
                    echo "❌ 文件不存在。"
                fi
                read -p "按回车继续其他功能菜单..."
                ;;
            4)
                read -p "请输入分组文件名（如 group_test.txt，或输入 0 返回）: " fname
                [ "$fname" == "0" ] && continue
                full="$GROUPS_DIR/$fname"
                if [ ! -f "$full" ]; then
                    echo "❌ 文件不存在。"
                else
                    mapfile -t IDS < "$full"
                    for id in "${IDS[@]}"; do
                        if screen -ls | grep -q "nexu_${id}"; then
                            echo "ID $id 已在运行，跳过。"
                        else
                            screen -S "nexu_${id}" -dm bash -c "$NEXUS_BIN start --node-id $id --max-threads 20"
                            echo "已启动ID：$id"
                        fi
                    done
                    echo "✅ 分组已启动完毕。"
                fi
                read -p "按回车继续其他功能菜单..."
                ;;
            5)
                echo "当前所有 screen 会话："
                screen -ls | grep "nexu_" | awk '{print $1}' || echo "无运行中的 screen 会话"
                read -p "请输入要进入的会话名（或输入 0 返回）: " session

                # 如果用户输入的 ID 没有前缀，自动添加前缀 "nexu_"
                if [[ "$session" != "0" ]]; then
                    if [[ ! "$session" =~ ^nexu_ ]]; then
                        session="nexu_$session"
                    fi

                    # 检查该会话是否存在
                    if screen -ls | grep -q "$session"; then
                        screen -r "$session"
                        echo "✅ 已退出 screen。"
                    else
                        echo "❌ 会话 $session 不存在。"
                    fi
                else
                    echo "返回主菜单。"
                fi
                read -p "按回车继续其他功能菜单..."
                ;;
            0) return ;;
            *) echo "无效选项，请重新输入。"; read; clear; continue ;;
        esac
    done
}

# 显示主菜单
show_menu() {
    clear
    echo "=============================================="
    echo " Nexus 多ID运行管理工具（v4.2.1）By:Ccool"
    echo "=============================================="
    echo " 1) 一键后台启动ID"
    echo " 2) 自动轮换下一批"
    echo " 3) 检查并恢复失效ID"
    echo " 4) 一键关闭所有 ID"
    echo " 5) 一键监控ID运行情况"
    echo " 6) 查看批次运行记录"
    echo " 7) 其他功能 >>>"
    echo " 8) 一键退出脚本（ID仍保持运行）"
    echo "=============================================="
    echo -n "请选择操作 (1-8): "
}

# 主循环
while true; do
    show_menu
    read choice
    case $choice in
        1) start_id_by_batch ;;
        2) schedule_next_batch ;;
        3) detect_and_recover_batches ;;
        4) stop_all_nodes ;;
        5) view_node_status ;;
        6) view_batch_log ;;
        7) other_functions_menu ;;
        8)
            read -p "确认退出？运行中的ID不会受到影响 (y/n): " confirm
            [ "$confirm" == "y" ] && echo "感谢使用，已退出。" && exit 0
            ;;
        *) echo "无效选项，请重新输入"; read; clear ;;
    esac
done