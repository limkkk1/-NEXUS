import os
import re
import shutil
import argparse
import subprocess
import logging

# 配置日志
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def find_path(target, start_dir):
    """查找文件路径，防止命令注入"""
    try:
        cmd = ["find", start_dir, "-name", target, "-type", "f"]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        paths = result.stdout.strip().split('\n')
        return paths[0] if paths and paths[0] else None
    except subprocess.CalledProcessError as e:
        logging.error(f"查找文件 {target} 失败: {e}")
        return None
    except Exception as e:
        logging.error(f"查找文件 {target} 时发生未知错误: {e}")
        return None

def find_dir(target, start_dir):
    """查找目录路径，防止命令注入"""
    try:
        cmd = ["find", start_dir, "-name", target, "-type", "d"]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        paths = result.stdout.strip().split('\n')
        return paths[0] if paths and paths[0] else None
    except subprocess.CalledProcessError as e:
        logging.error(f"查找目录 {target} 失败: {e}")
        return None
    except Exception as e:
        logging.error(f"查找目录 {target} 时发生未知错误: {e}")
        return None

def find_screen_executable(screen_dir):
    """在指定目录下查找 screen 可执行文件"""
    screen_path = os.path.join(screen_dir, "screen")
    if os.path.isfile(screen_path) and os.access(screen_path, os.X_OK):
        return screen_path
    logging.warning(f"在 {screen_dir} 中未找到可执行的 screen 文件")
    return None

def prompt_for_path(target, target_type):
    """提示用户输入未找到的路径，并验证权限"""
    while True:
        path = input(f"未找到 {target_type} '{target}'，请手动输入完整路径（或按回车跳过，使用默认值）：")
        if not path:
            return None
        path = os.path.abspath(path)  # 规范化路径
        if target_type == "file" and os.path.isfile(path) and os.access(path, os.R_OK):
            return path
        elif target_type == "directory" and os.path.isdir(path) and os.access(path, os.R_OK):
            return path
        print(f"输入的路径无效或不可访问，请确保 '{path}' 是一个有效的 {target_type}。")

def get_paths(base_dir):
    """查找路径，未找到则提示用户输入"""
    paths = {
        "nexus_bin": find_path("nexus-network", base_dir),
        "all_ids_file": find_path("all_node_ids.txt", base_dir),
        "last_index_file": find_path("last_batch_index.txt", base_dir),
        "groups_dir": find_dir("groups", base_dir),
        "log_dir": find_dir("logs", base_dir),
        "screen_dir": find_dir("screen-4.9.1", base_dir)  # 新增
    }
    
    # 默认路径
    defaults = {
        "nexus_bin": f"{base_dir}/build-nexus083/clients/cli/target/release/nexus-network",
        "all_ids_file": f"{base_dir}/nexus-batch/all_node_ids.txt",
        "last_index_file": f"{base_dir}/nexus-batch/last_batch_index.txt",
        "groups_dir": f"{base_dir}/nexus-batch/groups",
        "log_dir": f"{base_dir}/nexus-batch/logs",
        "screen_dir": f"{base_dir}/screen-4.9.1"  # 新增
    }
    
    # 提示未找到的路径
    not_found = []
    for key, path in paths.items():
        if not path:
            not_found.append(key)
            logging.info(f"未找到 {key.replace('_', ' ')}")
            if key in ["nexus_bin", "all_ids_file", "last_index_file"]:
                paths[key] = prompt_for_path(defaults[key].split('/')[-1], "file") or defaults[key]
            else:
                paths[key] = prompt_for_path(defaults[key].split('/')[-1], "directory") or defaults[key]
    
    # 验证 screen 可执行文件
    if paths["screen_dir"]:
        screen_path = find_screen_executable(paths["screen_dir"])
        if not screen_path:
            logging.warning("未找到 screen 可执行文件，将使用系统默认 screen")
            paths["screen_dir"] = None  # 如果没有有效的 screen，设置为 None
    
    if not_found:
        print("\n以下路径未自动找到，已使用用户输入或默认值：")
        for key in not_found:
            print(f"{key.replace('_', ' ')}: {paths[key]}")
    
    return paths

def update_script(script_path, paths):
    """更新脚本中的路径"""
    # 检查脚本是否存在
    if not os.path.isfile(script_path):
        logging.error(f"脚本 {script_path} 不存在")
        raise FileNotFoundError(f"脚本 {script_path} 不存在")
    
    # 备份原始脚本，避免覆盖已有备份
    backup_path = script_path + '.bak'
    counter = 1
    while os.path.exists(backup_path):
        backup_path = f"{script_path}.{counter}.bak"
        counter += 1
    shutil.copy(script_path, backup_path)
    logging.info(f"已备份原始脚本到 {backup_path}")
    
    # 读取脚本
    with open(script_path, 'r') as f:
        content = f.read()
    
    # 替换路径，使用更健壮的正则表达式
    replacements = {
        r'^NEXUS_BIN\s*=\s*"[^"]*"\s*$': f'NEXUS_BIN="{paths["nexus_bin"]}"',
        r'^ALL_IDS_FILE\s*=\s*"[^"]*"\s*$': f'ALL_IDS_FILE="{paths["all_ids_file"]}"',
        r'^LAST_INDEX_FILE\s*=\s*"[^"]*"\s*$': f'LAST_INDEX_FILE="{paths["last_index_file"]}"',
        r'^GROUPS_DIR\s*=\s*"[^"]*"\s*$': f'GROUPS_DIR="{paths["groups_dir"]}"',
        r'^LOG_DIR\s*=\s*"[^"]*"\s*$': f'LOG_DIR="{paths["log_dir"]}"'
    }
    
    for pattern, replacement in replacements.items():
        content = re.sub(pattern, replacement, content, flags=re.MULTILINE)
    
    # 更新 PATH，添加 screen-4.9.1 目录
    if paths["screen_dir"]:
        screen_bin_dir = paths["screen_dir"]
        # 查找 export PATH 行
        path_pattern = r'^export PATH\s*=\s*"[^"]*"\s*$'
        if re.search(path_pattern, content, flags=re.MULTILINE):
            # 替换现有 PATH，追加 screen_bin_dir
            content = re.sub(
                path_pattern,
                f'export PATH="$HOME/local/bin:{screen_bin_dir}:$PATH"',
                content,
                flags=re.MULTILINE
            )
        else:
            # 如果没有 PATH 行，在文件开头添加
            content = f'export PATH="$HOME/local/bin:{screen_bin_dir}:$PATH"\n{content}'
        logging.info(f"已将 {screen_bin_dir} 添加到 PATH")
    
    # 保存新脚本
    new_script_path = script_path.replace('.sh', '_adapted.sh')
    with open(new_script_path, 'w') as f:
        f.write(content)
    
    # 设置执行权限
    os.chmod(new_script_path, 0o755)
    logging.info(f"已生成适配脚本：{new_script_path}")
    print(f"\n已生成适配脚本：{new_script_path}")
    print("请检查以下路径是否正确：")
    for key, path in paths.items():
        print(f"{key.replace('_', ' ')}: {path}")

def main():
    parser = argparse.ArgumentParser(description='Adapt Nexus script paths for VPS environment')
    parser.add_argument('--script', required=True, help='Path to the Nexus script')
    parser.add_argument('--base-dir', default=os.path.expanduser('~'), help='Base directory for path search')
    args = parser.parse_args()

    # 获取路径
    paths = get_paths(args.base_dir)
    
    # 更新脚本
    update_script(args.script, paths)

if __name__ == '__main__':
    main()